#!/bin/bash

khs=1
stats_json="
  { 
	'hs': [123, 223.3],
	'hs_units': 'khs', 
	'temp': [60, 63],
	'fan': [80, 100],
	'uptime': 12313232,
	'ver': '1.0.0'
  }
"
